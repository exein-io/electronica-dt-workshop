#include <stdio.h>
#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>
#include <zephyr/sys/printk.h>
#include <modem/nrf_modem_lib.h>

int main()
{
    printk("APP nRF91xx vUICC core started\n");
    
    nrf_modem_lib_init();

    while (1) {
        k_msleep(500);
    }

    return 0;
}
