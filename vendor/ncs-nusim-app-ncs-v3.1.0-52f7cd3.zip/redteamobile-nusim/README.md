# Redtea Mobile nuSIM Integration

The present repository contains the nuSIM implementation from Redtea Mobile for Nordic nRF91 series LPWA radio modules. It includes all necessary components for firmware integration and profile handling for (test) provisioning along with comprehensive documentation. The main contents are:

| Folder               | Name                                                  |
| ---                  | ---                                                   |
| doc                  | The documents for integration and user guides         |
| lib                  | The application codes for nuSIM AT and softSIM implements  |
| rtxuicc              | The delivery nuSIM library for NCS                    |
| samples              | Sample projects for reference                         |
| sysbuild             | The sysbuild cmake script                             |
| tools                | The tools used for nuSIM test and debug               |
| zephyr               | The zephyr configuration for the module               |
| Kconfig              | Default kconfig options for the modules               |
| overlay-nusim.conf   | The overlay configurations for nuSIM, must inlcude within your compile command     |

Note: This repository has different branches corresponding to different NCS versions. Please use the branch that corresponds to your NCS version. The security-certified version is: https://github.com/redteamobile/ncs-nusim-app/tree/v1.0.9.0-ncs_v2.5.2


## Get Started
###  Documentation

The latest official release of a pre-built PDF documentation is in the folder: [**nusim_library/deploy/nuSIM_For_Nordic_nRF91xx.pdf**](./doc/nusim_library/deploy/nuSIM_For_Nordic_nRF91xx.pdf).

You can also build the document yourself following the [offical sphinx guideline](https://www.sphinx-doc.org/en/master/#get-started) to setup your building environment on windows/Linux/macOS.

Firstly, you need to change to the doc folder:
```sh
cd doc/nusim_library
```
#### HTML
the Sphinx documentation (HTML) can be built using the following command:
```
make html
```
the html files are under the folder **_build_sphinx/html**.

#### PDF
You need to install [MiKTex](https://miktex.org/download) on windows, remember to check **"Install missing packages on-the-fly"** option.

For linux, you need to install latexmk and texlive-latex-extra etc:
```sh
apt-get install -y make texlive-latex-base texlive-latex-recommended \
            texlive-latex-extra texlive-fonts-recommended latexmk
```

Using the following command to build the pdf:
```
make latexpdf
```
the pdf file is under the folder **_build_sphinx/latex**.


### Integration

Please refer to the Integration documentation for detailed instructions on how to integrate nuSIM into your project.

### IALA (Initialization Application and Loading Application)

The IALA is a tool used for nuSIM initialization and profile loading, available for both Windows and Linux platforms. Please refer to the IALA documentation to get the details.

### Support

For further support, please contact Redtea Mobile via nusim@redteamobile.com


