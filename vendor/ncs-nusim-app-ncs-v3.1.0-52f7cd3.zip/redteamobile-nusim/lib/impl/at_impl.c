#include <zephyr/logging/log.h>
#include <nrf_modem_at.h>
#include <modem/at_parser.h>
#include <modem/at_cmd_custom.h>
#include "rtcosapi.h"

LOG_MODULE_DECLARE(lib_nusim, CONFIG_LIB_NUSIM_LOG_LEVEL);

#define NUSIM_AT_CMD  "+NUSIM"
#define AT_CMD_OK "\r\nOK\r\n"
#define AT_CMD_ERROR "\r\nERROR\r\n"
#define MAX_AT_BUFF_SIZE 576

/* Define as global to prevent stack overflow. */
static uint8_t g_apdu_recv_buf[COS_MAX_APDU_RESP_SIZE];
static uint8_t g_apdu_send_buf[COS_MAX_APDU_SIZE];
static uint8_t g_hex_recv_buf[MAX_AT_BUFF_SIZE];
static uint8_t g_softsim_en = 0;

#define WARM_RESET_CMD    '2'
#define COLD_RESET_CMD    '3'

typedef enum {
    AT_RESET_UNKNOWN = 0,
    AT_RESET_WARM,
    AT_RESET_COLD,
    AT_RESET_FACTORY,
} AT_RESET_CMD_E;

static AT_RESET_CMD_E g_at_rst_cmd = AT_RESET_UNKNOWN;

#define AT_HANDLE_STACK_SIZE 320
#define AT_HANDLE_PRIORITY 8

K_THREAD_STACK_DEFINE(at_handle_stack_area, AT_HANDLE_STACK_SIZE);

static struct k_work_q at_handle_work_q;
static struct k_work at_reset_handler;

static void at_handle_reset_request(struct k_work *work)
{
    switch (g_at_rst_cmd) {
        case AT_RESET_WARM:
            LOG_INF("nuSIM warm reset");
            rt_cos_api_sytem_reset(WARM_RESET);
            break;
        case AT_RESET_COLD:
            LOG_INF("nuSIM cold reset");
            rt_cos_api_sytem_reset(COLD_RESET);
            break;
        default:
            break;
    }

    g_at_rst_cmd = AT_RESET_UNKNOWN;
}

static int rt_nusim_at_handle_request(void)
{
    /* Start a work queue for at requst handling. */
    k_work_queue_start(&at_handle_work_q, at_handle_stack_area,
                       K_THREAD_STACK_SIZEOF(at_handle_stack_area),
                       AT_HANDLE_PRIORITY, NULL);
    k_thread_name_set(&at_handle_work_q.thread, "softsim_at_handler");

    k_work_init(&at_reset_handler, at_handle_reset_request);

    return 0;
}

static inline int8_t is_lfcr(char chr)
{
    if ((chr == '\r') || (chr == '\n')) {
        return 1;
    }

    return 0;
}

/* definition of static handler for Redtea nuSIM AT parser */
static int at_impl_redtea_handler(char *buf, size_t len, char *at_cmd)
{
    enum at_parser_cmd_type cmd_type;
    struct at_parser parser;
    int8_t res;
    uint16_t apdu_recv_len;
    uint16_t apdu_send_len;
    int16_t dlen;

    /* Skip lfcr */
    while (is_lfcr(*at_cmd)) {
        at_cmd ++;
    }

    dlen = strlen(at_cmd);
    if (at_cmd[dlen - 1] == '\r') {
        at_cmd[dlen - 1] = '\0';
    }

    if (at_parser_init(&parser, at_cmd) != 0) {
        LOG_DBG("%s -- at_parser_init error\n", __func__);
        snprintf(buf, len, NUSIM_AT_CMD":Error"AT_CMD_ERROR);
        return 0;
    }

    if (at_parser_cmd_type_get(&parser, &cmd_type) != 0) {
        LOG_DBG("%s -- at_parser_cmd_type_get error\n", __func__);
        snprintf(buf, len, NUSIM_AT_CMD":Error"AT_CMD_ERROR);
        return 0;
    }

    LOG_DBG("nuSIM AT cmd: %s, cmd type: %d", at_cmd, cmd_type);

    if (AT_PARSER_CMD_TYPE_READ == cmd_type) { /* read nusim version: AT+NUSIM? */
        res = rt_cos_api_get_ver(g_apdu_recv_buf, &apdu_recv_len);
        if (res == COS_SUCCESS) {
            g_apdu_recv_buf[apdu_recv_len] = '\0';
            snprintf(buf, len, NUSIM_AT_CMD":%s"AT_CMD_OK, (char*)g_apdu_recv_buf);
        } else {
            snprintf(buf, len, NUSIM_AT_CMD":Error"AT_CMD_ERROR);
        }
    } else if (AT_PARSER_CMD_TYPE_TEST == cmd_type) { /* query nusim state: AT+NUSIM=? */
        snprintf(buf, len, NUSIM_AT_CMD":%d"AT_CMD_OK, g_softsim_en); /* Always be enabled */
    } else if (AT_PARSER_CMD_TYPE_SET == cmd_type) { /* update nusim state: AT+NUSIM=<APDU CMD> */
        int ret = 0, str_len = 0;
        char *parameter = at_cmd + strlen(NUSIM_AT_CMD) + 3;

        str_len = strlen(parameter);
        if (str_len == 1) { /* one byte -- AT+NUSIM=0/1 */
            if (*parameter == '0' || *parameter == '1') {
                snprintf(buf, len, NUSIM_AT_CMD":1"AT_CMD_OK);
                g_softsim_en = (*parameter == '0') ? 0:1;
            } else if (*parameter == WARM_RESET_CMD) { /* warm reset */
                snprintf(buf, len, NUSIM_AT_CMD":"AT_CMD_OK);
                g_at_rst_cmd = AT_RESET_WARM;
                k_work_submit(&at_reset_handler);
            } else if (*parameter == COLD_RESET_CMD) { /* cold reset */
                snprintf(buf, len, NUSIM_AT_CMD":"AT_CMD_OK);
                g_at_rst_cmd = AT_RESET_COLD;
                k_work_submit(&at_reset_handler);
            } else {
                snprintf(buf, len, NUSIM_AT_CMD":Error"AT_CMD_ERROR);
            }
        } else {
            /* other data is APDU */
            memcpy(g_hex_recv_buf, parameter, MAX_AT_BUFF_SIZE);
            apdu_send_len = hex2bin(g_hex_recv_buf, str_len, &g_apdu_send_buf[0],
                                    sizeof(g_apdu_send_buf));

            /* msg length is limited with MAX apdu msg size */
            if (apdu_send_len > COS_MAX_APDU_SIZE || apdu_send_len == 0) {
                /* Fill response buffer. */
                snprintf(buf, len, NUSIM_AT_CMD":APDU Length Error"AT_CMD_ERROR);
                return 0;
            }

            ret = rt_cos_api_send_recv_msg(g_apdu_send_buf, apdu_send_len, g_apdu_recv_buf, &apdu_recv_len);
            if (ret == COS_SUCCESS) {
                bin2hex(g_apdu_recv_buf, apdu_recv_len, g_hex_recv_buf, sizeof(g_hex_recv_buf));
                snprintf(buf, len, NUSIM_AT_CMD":%s"AT_CMD_OK, g_hex_recv_buf);
            } else {
                snprintf(buf, len, NUSIM_AT_CMD":Error %d"AT_CMD_OK, ret);
            }
            LOG_DBG("nuSIM AT resp: %s", buf);
        }
    } else {
        /* Fill response buffer. */
        snprintf(buf, len, NUSIM_AT_CMD":Error"AT_CMD_ERROR);
    }

    return 0;
}

/* Callback for +NUSIM calls */
AT_CMD_CUSTOM(redtea_at_cmd_filters, "AT+NUSIM", at_impl_redtea_handler);

SYS_INIT(rt_nusim_at_handle_request, APPLICATION, 0);
