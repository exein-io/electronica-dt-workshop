#include <zephyr/logging/log.h>
#include <modem/nrf_modem_lib.h>
#include <nrf_modem_softsim.h>
#include "rtcosapi.h"

#ifdef CONFIG_LIB_NUSIM_AUTO_SELECT
#include <nrf_modem_at.h>
#endif

LOG_MODULE_REGISTER(lib_nusim, CONFIG_LIB_NUSIM_LOG_LEVEL);

static void softsim_init_async(uint16_t req_id, void *data, uint16_t data_len);
static void softsim_apdu_async(uint16_t req_id, void *data, uint16_t data_len);
static void softsim_deinit_async(uint16_t req_id);
static void softsim_reset_async(uint16_t req_id);

static uint8_t g_softsim_recv_buff[COS_MAX_APDU_RESP_SIZE];
static uint16_t g_softsim_recv_len;

/* The XUICC Partition service ID defined in Partition YAML */
#define XUICC_SID 0x000000FA

static uint8_t g_atr[64];
static uint8_t g_atr_len;

#define SOFTSIM_PRIORITY 7

struct softsim_request_t {
    enum nrf_modem_softsim_cmd cmd;
    uint16_t req_id;
    void *data;
    uint16_t data_len;
};

static struct softsim_request_t g_softsim_req;

K_THREAD_STACK_DEFINE(softsim_stack_area, CONFIG_LIB_NUSIM_STACK_SIZE);
K_SEM_DEFINE(softsim_req_trigger, 0, 1);

static struct k_thread softsim_thread_data;

static void cos_init_error_msg(int result)
{
    switch (result) {
    case COS_CMD_INVALID_TYPE:
        LOG_ERR("cos init failure: Invalid cmd type");
        break;
    case COS_IO_ID_ERROR:
        LOG_ERR("cos init failure: IO id error");
        break;
    case COS_IO_HANDLE_ERROR:
        LOG_ERR("cos init failure: IO handle error");
        break;
    case COS_RECV_DATA_ERROR:
        LOG_ERR("cos init failure: recv data error");
        break;
    case COS_DATA_LENGTH_ERROR:
        LOG_ERR("cos init failure: data length error");
        break;
    case COS_DATA_CHKSUM_ERROR:
        LOG_ERR("cos init failure: data checksum error");
        break;
    case COS_DATA_HEADER_ERROR:
        LOG_ERR("cos init failure: data header error");
        break;
    case COS_APDU_DATA_ERROR:
        LOG_ERR("cos init failure: apdu data error");
        break;
    case COS_INVALID_TFM_ROT_SID:
        LOG_ERR("cos init failure: invalid tfm rot sid");
        break;
    case COS_GET_TFM_VERSION_FAILURE:
        LOG_ERR("cos init failure: get tfm version failure");
        break;
    case COS_PSA_CONNECT_TFM_SERV_ERROR:
        LOG_ERR("cos init failure: psa connect tfm serv error");
        break;
    case COS_PSA_CALL_SEND_MSG_ERROR:
        LOG_ERR("cos init failure: psa call send msg error");
        break;
    default:
        LOG_ERR("cos init failure: unknown error");
        break;
    }
}

static void softsim_req_handler(void *a, void *b, void *c)
{
    int rc;

    while (1) {
        rc = k_sem_take(&softsim_req_trigger, K_FOREVER);
        if (rc != 0) {
            LOG_ERR("Input data not available -- rc: %d !", rc);
            continue;
        }

        switch (g_softsim_req.cmd) {
        case NRF_MODEM_SOFTSIM_INIT:
            /* Process INIT. */
            softsim_init_async(g_softsim_req.req_id, g_softsim_req.data, g_softsim_req.data_len);
            break;

        case NRF_MODEM_SOFTSIM_APDU:
            /* Process APDU. */
            softsim_apdu_async(g_softsim_req.req_id, g_softsim_req.data, g_softsim_req.data_len);
            break;

        case NRF_MODEM_SOFTSIM_DEINIT:
            /* Process DEINIT. */
            softsim_deinit_async(g_softsim_req.req_id);
            break;

        case NRF_MODEM_SOFTSIM_RESET:
            /* Process RESET. */
            softsim_reset_async(g_softsim_req.req_id);
            break;

        default:
            break;
        }

        LOG_DBG("cmd:%d req_id:%d data_len:%d complete", g_softsim_req.cmd, g_softsim_req.req_id,
                g_softsim_req.data_len);
    }
}

/* Implementation of `nrf_modem_softsim_req_handler_t`. */
static void softsim_isr_handler(enum nrf_modem_softsim_cmd cmd, uint16_t req_id, void *data,
                                uint16_t data_len)
{
    g_softsim_req.cmd = cmd;
    g_softsim_req.req_id = req_id;
    g_softsim_req.data = data;
    g_softsim_req.data_len = data_len;

    /* post msg */
    k_sem_give(&softsim_req_trigger);
}

static void softsim_init_async(uint16_t req_id, void *data, uint16_t data_len)
{
    if (g_atr_len > 0) {
        nrf_modem_softsim_res(NRF_MODEM_SOFTSIM_INIT, req_id, g_atr, g_atr_len);
    } else {
        nrf_modem_softsim_err(NRF_MODEM_SOFTSIM_INIT, req_id);
    }
}

/* Transform APDU Extended into Short mode. */
static int short_apdu_transformation(uint8_t* apdu, uint16_t apdu_len, uint8_t* out_short_apdu,
                                     uint16_t* out_len)
{
    uint8_t C5, C6, C7;

    C5 = apdu[4];
    if ((apdu_len <= 5) || (C5 == (apdu_len - 5)) || (C5 == (apdu_len - 6))) {
        *out_len = apdu_len;
        memcpy(out_short_apdu, apdu, apdu_len);
        return 0;
    }

    if ((C5 == 0) && (apdu_len == 7)) { /* 2E */
        memcpy(out_short_apdu, apdu, 5);
        *out_len = 5;
        return 0;
    }

    C6 = apdu[5];
    if ((C5 == 0) && (C6 == 0) && (apdu_len > 7)) { /* 3E.1 / 4E.1 */
        C7 = apdu[6];
        out_short_apdu[4] = C7;
        memcpy(out_short_apdu, apdu, 4);
        memcpy(out_short_apdu + 5, apdu + 7, C7);
        *out_len = 5 + C7;
        return 0;
    }

    /* Fail for NOT Support */
    return -1;
}

static void softsim_apdu_async(uint16_t req_id, void *data, uint16_t data_len)
{
    uint16_t apdu_len = 0;
    uint8_t fapdu[5], napdu[300];
    int8_t res;

    LOG_HEXDUMP_DBG(data, data_len, "Command APDU");

    if (short_apdu_transformation((uint8_t*)data, data_len, napdu, &apdu_len) != 0) {
        LOG_ERR("APDU transformation failed");
        nrf_modem_softsim_err(NRF_MODEM_SOFTSIM_APDU, req_id);
        goto clean_exit;
    }

    /* APDU length is limited to COS_MAX_APDU_SIZE */
    if ((apdu_len == 0) || (apdu_len > COS_MAX_APDU_SIZE)) {
        LOG_ERR("APDU length error: %d", apdu_len);
        nrf_modem_softsim_err(NRF_MODEM_SOFTSIM_APDU, req_id);
        goto clean_exit;
    }

    res = rt_cos_api_send_recv_msg(napdu, apdu_len, g_softsim_recv_buff, &g_softsim_recv_len);
    if (res != COS_SUCCESS) {
        LOG_ERR("APDU send/recv error: %d", res);
        nrf_modem_softsim_err(NRF_MODEM_SOFTSIM_APDU, req_id);
        goto clean_exit;
    }

    /* Check for use of procedure bytes '61xx' and '6Cxx' */
    if ((g_softsim_recv_len == 2) &&
        ((g_softsim_recv_buff[0] == 0x61) || (g_softsim_recv_buff[0] == 0x6C))) {
        fapdu[0] = 0x80;
        fapdu[1] = 0xC0;
        fapdu[2] = 0x00;
        fapdu[3] = 0x00;
        fapdu[4] = g_softsim_recv_buff[1];

        res = rt_cos_api_send_recv_msg(fapdu, 5, g_softsim_recv_buff, &g_softsim_recv_len);
        if (res != COS_SUCCESS) {
            LOG_ERR("APDU send/recv error: %d", res);
            nrf_modem_softsim_err(NRF_MODEM_SOFTSIM_APDU, req_id);
            goto clean_exit;
        }
    }

    LOG_HEXDUMP_DBG(g_softsim_recv_buff, g_softsim_recv_len, "Response APDU");
    nrf_modem_softsim_res(NRF_MODEM_SOFTSIM_APDU, req_id, g_softsim_recv_buff, g_softsim_recv_len);

clean_exit:
    if (data) {
        nrf_modem_softsim_data_free((void*)data);
    }
}

static void softsim_deinit_async(uint16_t req_id)
{
    nrf_modem_softsim_res(NRF_MODEM_SOFTSIM_DEINIT, req_id, NULL, 0);
}

static void softsim_reset_async(uint16_t req_id)
{
    nrf_modem_softsim_res(NRF_MODEM_SOFTSIM_RESET, req_id, NULL, 0);
}

static int rt_nusim_softsim_init(void)
{
    k_tid_t k_tid;
    int8_t res;
    int err;

    LOG_INF("Init SoftSIM request handler");

    res = rt_cos_api_init(g_atr, &g_atr_len, XUICC_SID);
    if (res != COS_SUCCESS) {
        cos_init_error_msg(res);
        return -1;
    }

    /* Start a single thread for APDU handling. */
    k_tid = k_thread_create(&softsim_thread_data, softsim_stack_area,
                            K_THREAD_STACK_SIZEOF(softsim_stack_area),
                            softsim_req_handler, NULL, NULL, NULL,
                            SOFTSIM_PRIORITY, 0, K_NO_WAIT);
    k_thread_name_set(k_tid, "softsim_req_handler");

    err = nrf_modem_softsim_req_handler_set(softsim_isr_handler);
    if (err) {
        LOG_ERR("nrf_modem_softsim_req_handler_set() failure: %d", err);
        return -1;
    }

    return 0;
}

SYS_INIT(rt_nusim_softsim_init, APPLICATION, 0);

#ifdef CONFIG_LIB_NUSIM_AUTO_SELECT
static void on_modem_lib_init(int ret, void *ctx)
{
  int err;

  if (ret) {
    LOG_ERR("Modem library did not initialize: %d", ret);
    return;
  }

  err = nrf_modem_at_printf("AT%%CSUS=2");
  if (err) {
    LOG_ERR("Failed to select virtual iUICC: %d", err);
  }
}

NRF_MODEM_LIB_ON_INIT(sim_select_hook, on_modem_lib_init, NULL);
#endif
