#ifndef __RT_COS_API_H__
#define __RT_COS_API_H__
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

//max apdu command size for cos
#define COS_MAX_APDU_SIZE 260

//max apdu response size for cos
#define COS_MAX_APDU_RESP_SIZE 258

#define WARM_RESET        0
#define COLD_RESET        1

/* result codes for COS api interfaces */
#define COS_SUCCESS       0
#define COS_FAILURE      -1
#define COS_CMD_INVALID_TYPE -100
#define COS_IO_ID_ERROR     -101
#define COS_IO_HANDLE_ERROR -102
#define COS_RECV_DATA_ERROR -103
#define COS_DATA_LENGTH_ERROR -104
#define COS_DATA_CHKSUM_ERROR -105
#define COS_DATA_HEADER_ERROR -106
#define COS_APDU_DATA_ERROR -107
#define COS_INVALID_TFM_ROT_SID -108
#define COS_GET_TFM_VERSION_FAILURE -109
#define COS_PSA_CONNECT_TFM_SERV_ERROR -110
#define COS_PSA_CALL_SEND_MSG_ERROR -111

/**
 * \brief initialize for cos task
 *
 * \param[in] art        buffer for storing atr.
 * \param[in] art_len    length of atr.
 * \param[in] xuicc_sid   sid of xuicc rot service.
 * \retval COS_SUCCESS or error codes for failure.
 */
int8_t rt_cos_api_init(uint8_t *atr, uint8_t *atr_len, int32_t xuicc_sid);

/**
 * \brief Get cos version info
 *
 * \param[in] ver        version string buffer
 * \param[in] ver_len    length of version.
 * \retval COS_SUCCESS or error codes for failure.
 */
int8_t rt_cos_api_get_ver(uint8_t *ver, uint16_t *ver_len);

/**
 * \brief send apdu request to cos and get response.
 *
 * \param[in] req         apdu request data in bytes.
 * \param[in] req_len     length of request data, max length of request data is COS_MAX_APDU_SIZE
 * \param[in] resp        response data in bytes.
 * \param[in] resp_len    length of resp, the max length of resp is COS_MAX_APDU_RESP_SIZE, resp buffer must be preallocated with max size.
 * \retval COS_SUCCESS or error codes for failure.
 */
int8_t rt_cos_api_send_recv_msg(const uint8_t *req, uint16_t req_len, uint8_t *resp, uint16_t *resp_len);

/**
 * \brief force system reboot.
 * \param[in] type WARM_RESET , COLD_RESET
 * \retval COS_SUCCESS or COS_FAILURE.
 */
int8_t rt_cos_api_sytem_reset(int8_t type);

#endif //__RT_COS_API_H__
