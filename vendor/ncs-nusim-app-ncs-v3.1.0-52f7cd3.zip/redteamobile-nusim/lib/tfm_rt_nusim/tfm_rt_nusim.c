/*
 * Copyright (c) 2022 Nordic Semiconductor ASA.
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

#include <psa/crypto.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "rt_xuicc.h"

#include "psa_manifest/tfm_rt_nusim.h"
#include "psa/service.h"
#include <psa/storage_common.h>
#include <psa/internal_trusted_storage.h>

static psa_msg_t g_recv_msg;

/* msg size from client (do not change) */
#define XUICC_MSG_BUF_SIZE 304

psa_status_t xuicc_process_psa_msg(psa_msg_t *in_out_msg)
{
    size_t msg_size = 0;
    uint8_t msg_buf[XUICC_MSG_BUF_SIZE];
    uint8_t resp_buf[XUICC_MSG_BUF_SIZE];

    if (!in_out_msg || !in_out_msg->in_size[0] || !in_out_msg->handle) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    memset(&msg_buf, 0, sizeof(msg_buf));
    memset(&resp_buf, 0, sizeof(resp_buf));

    if (psa_read(in_out_msg->handle, 0, msg_buf, sizeof(msg_buf)) != XUICC_MSG_BUF_SIZE) {
        return PSA_ERROR_PROGRAMMER_ERROR;
    }

    /* call xuicc handle msg */
    rt_xuicc_handle_msg(msg_buf, resp_buf, &msg_size);

    /* write response with response */
    if (msg_size && in_out_msg->out_size[0] != 0) {
        psa_write(in_out_msg->handle, 0, (void*)resp_buf, msg_size);
    }

    return PSA_SUCCESS;
}

static void xuicc_service(void)
{
    uint8_t result;

    psa_get(TFM_RT_NUSIM_SERVICE_SIGNAL, &g_recv_msg);
    switch (g_recv_msg.type) {
    case PSA_IPC_CONNECT:
    case PSA_IPC_DISCONNECT:
        /*
         * This service does not require any setup or teardown on connect
         * or disconnect, so just reply with success.
         */
        psa_reply(g_recv_msg.handle, PSA_SUCCESS);
        break;
    case PSA_IPC_CALL:
        /* handle ipc msg */
        result = xuicc_process_psa_msg(&g_recv_msg);
        psa_reply(g_recv_msg.handle, result);
        break;
    default:
        /* cannot get here [broken SPM] */
        psa_panic();
        break;
    }
}

int tfm_nusim_main(void)
{
    psa_signal_t signals = 0;

    /* xuicc initialization */
    if (rt_xuicc_init() != 0) {
        return -1;
    }

    /*
     * Continually wait for one or more of the partition's RoT Service or
     * interrupt signals to be asserted and then handle the asserted
     * signal(s).
     */
    while (1) {
        signals = psa_wait(PSA_WAIT_ANY, PSA_BLOCK);
        if (signals & TFM_RT_NUSIM_SERVICE_SIGNAL) {
            xuicc_service();
        } else {
            /* Should not come here */
            psa_panic();
        }
    }

    return 0;
}
