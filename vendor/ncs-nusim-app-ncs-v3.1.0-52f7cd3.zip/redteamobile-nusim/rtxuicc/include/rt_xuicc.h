#ifndef __RT_XUICC_H__
#define __RT_XUICC_H__

/**
 * \brief initialize xuicc os
 * \retval 0 for success, -1 for failure.
 */
int rt_xuicc_init(void);

/**
 * \brief handling msg from client and get response.
 *
 * \param[in] msg        msg buffer ptr.
 * \param[in] p_res      response buffer for data returned.
 * \param[in] resp_size   response data size.
 * \retval 0 for success, -1 for failure.
 */
int8_t rt_xuicc_handle_msg(uint8_t *msg, uint8_t *p_res, size_t *resp_size);

#endif  //__RT_XUICC_H__
