.. _la_linux_guide:

IALA for Linux
#################

Overview
==========

The Linux version of the IALA provides similar functionality to the Windows version, serving as a tool for nuSIM initialization and Profile Loading. However, it is implemented as a command-line tool with the following key features:

* Open source implementation, allowing users to understand and modify the code
* Includes demo code that demonstrates the library's usage
* Can be integrated into custom applications based on specific requirements
* Provides a comprehensive set of APIs for:

  * Device initialization and management
  * Profile loading and management
  * Communication with Personal Server (EUM)
  * Communication with Data Preparator (DP) server

The library is designed to be flexible and can be used either as a standalone command-line tool or integrated into larger applications. Users can refer to the provided demo code to understand how to use the library and implement their own solutions.

Package Contents
======================

The Linux version is distributed as a ZIP package containing the following files and directories:

* ``lib/`` - Directory containing:
  * ``libnuSIM_LA.so`` - The main library file
* ``LAConf.ini`` - Configuration file
* ``DemoNuSIMIALA`` - Demo application executable
* ``nuSIM_LA.h`` - Header file containing function declarations and documentation for libnuSIM_LA.so
* ``demo/`` - Demo directory containing:
  * ``demo.c`` - Demo source code

System Requirements
======================

The following system requirements must be met for proper initialization and loading of the application:

* GCC version: 11.4
* Glibc version: 2.35
* Platform: Linux x64

.. note:: The library is compiled with GCC 11.4 and Glibc 2.35 under Ubuntu 22.04. If you need to compile with different versions of GCC or Glibc, please contact Redtea.

Configurations
======================

The ``LAConf.ini`` file contains the following configuration sections similar with the Windows version, please contact Redtea for suitable configuration:

.. list-table:: Linux Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``ttyNamePrefix``
     - Linux tty name prefix (e.g., ttyACM for /dev/ttyACM0 in Ubuntu 22.04)

.. list-table:: Personal Server (EUM) Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``ps_server_addr``
     - HTTP URL for EUM server
   * - ``ps_server_access_key``
     - EUM server access key
   * - ``ps_server_access_secret``
     - EUM server access secret

.. list-table:: Download Profile Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``rootKeyID``
     - Root key ID
   * - ``dp_server_addr``
     - DP server address
   * - ``dp_root_tls_cert``
     - Root TLS certificate path
   * - ``dp_nusim_la_cert``
     - nuSIM LA certificate path
   * - ``dp_nusim_la_key``
     - nuSIM LA private key file path
   * - ``dp_nusim_la_key_passwd``
     - nuSIM LA private key password (leave blank if no password)
   * - ``dp_proxy``
     - Redtea Proxy setting (1: use proxy, 0: no proxy)
   * - ``proxy_server_addr``
     - Proxy server HTTP URL
   * - ``proxy_server_access_key``
     - Proxy server access key
   * - ``proxy_server_access_secret``
     - Proxy server access secret

.. list-table:: Reference Information Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``dp_refInfo1``
     - Reference info 1 (no backslashes or double quotes allowed)
   * - ``dp_refInfo2``
     - Reference info 2 (no backslashes or double quotes allowed)
   * - ``dp_refInfo3``
     - Reference info 3 (no backslashes or double quotes allowed)

.. list-table:: Port Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``auto_detect``
     - Auto detect devices (1: enabled, 0: disabled)
       * When enabled, works with ttyNamePrefix
       * When disabled, requires manual port configuration in [portList]
       * Recommended to set to 0 and configure ports manually due to various port names in Linux

.. list-table:: Port List Configuration
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Parameter
     - Description
   * - ``port0`` to ``port4``
     - Individual port names for each device
       * Example: port0 = ttyACM0
       * Leave blank if no device is connected

Main Functions
======================

The following are the main functions provided by the library:

Version and Log Functions
-------------------------

.. list-table:: Version and Log Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_VER_get()``
     - Get the library version information
   * - ``LA_LOG_config()``
     - Configure logging settings

COM Port Functions
-------------------

.. list-table:: COM Port Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_COM_enum()``
     - Enumerate available COM ports
   * - ``LA_COM_open()``
     - Open a COM port connection
   * - ``LA_COM_send_recv()``
     - Send and receive data through COM port
   * - ``LA_COM_close()``
     - Close COM port connection
   * - ``LA_COM_set_terminal_le()``
     - Set terminal line ending

.. note::
   The ``LA_COM_uart_fptr`` is a callback function type that needs to be implemented and passed to other interfaces for UART communication. It is specifically designed for Nordic production tester usage, allowing communication with devices without requiring a physical serial port. This is particularly useful in production testing environments where direct hardware serial port access might not be available or practical.

Example implementation and usage of UART communication callback:

.. code-block:: c

   // Define the UART communication callback function type
   typedef int (*LA_COM_uart_fptr)(int handle, const char* send, char* recv, int* recv_len, int timeout);

   // Implement your custom UART communication callback function
   int my_uart_communication(int handle, const char* send, char* recv, int* recv_len, int timeout)
   {
       // Your implementation here
       // handle: The device handle
       // send: The data to send
       // recv: Buffer to store the response
       // recv_len: Pointer to store the length of received data
       // timeout: Timeout value in milliseconds
       
       // Example implementation:
       int ret = 0;
       // Send data through your custom UART interface
       ret = send_data(handle, send, strlen(send));
       if (ret != 0) {
           return ret;
       }
       
       // Receive response from your custom UART interface
       ret = receive_data(handle, recv, recv_len, timeout);
       return ret;
   }

   // Pass the callback function to other interfaces
   int handle;
   // Example: Open COM port with custom UART communication
   LA_COM_open("COM1", 115200, &handle, my_uart_communication);
   
   // Example: Get device handle with custom UART communication
   LA_DEV_get_handle(0, &handle, my_uart_communication);
   
   // Example: Check device connection with custom UART communication
   LA_DEV_check_connected(handle, my_uart_communication);

Device Management Functions
----------------------------

.. list-table:: Device Management Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_DEV_get_handle()``
     - Get device handle
   * - ``LA_DEV_check_connected()``
     - Check device connection status
   * - ``LA_DEV_get_imei()``
     - Get device IMEI
   * - ``LA_DEV_get_nusim_version()``
     - Get nuSIM version
   * - ``LA_DEV_initialize()``
     - Initialize device
   * - ``LA_DEV_personalize()``
     - Personalize device
   * - ``LA_DEV_personalize_offline()``
     - Offline personalization
   * - ``LA_DEV_get_cm_cert()``
     - Get CM certificate
   * - ``LA_DEV_get_eid()``
     - Get device EID
   * - ``LA_DEV_load_profile()``
     - Load profile
   * - ``LA_DEV_get_iccid()``
     - Get ICCID
   * - ``LA_DEV_get_nusim_capability()``
     - Get nuSIM capabilities
   * - ``LA_DEV_get_nusim_cert()``
     - Get nuSIM certificate
   * - ``LA_DEV_get_attesttoken()``
     - Get attestation token

Personal Server (EUM) Functions
-------------------------------

.. list-table:: Personal Server (EUM) Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_PS_config_param()``
     - Configure EUM parameters
   * - ``LA_PS_req_init_data()``
     - Request initialization data
   * - ``LA_PS_request_bulk_nusim_certs()``
     - Request bulk nuSIM certificates
   * - ``LA_PS_retrieve_bulk_nusim_certs()``
     - Retrieve bulk nuSIM certificates
   * - ``LA_PS_query_nusim_certs_status()``
     - Query nuSIM certificates status
   * - ``LA_PS_query_merchant_balance()``
     - Query merchant balance (for LA proxy users)

Download Profile (DP) Functions
---------------------------------

.. list-table:: Download Profile Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_DP_config_proxy_mode()``
     - Configure proxy mode
   * - ``LA_DP_config_param()``
     - Configure DP parameters
   * - ``LA_DP_config_tls_certs()``
     - Configure TLS certificates
   * - ``LA_DP_request_bulk_enc_profiles()``
     - Request bulk encrypted profiles
   * - ``LA_DP_retrieve_bulk_enc_profiles()``
     - Retrieve bulk encrypted profiles
   * - ``LA_DP_get_auth_key()``
     - Get authentication key
   * - ``LA_DP_query_profile_stock()``
     - Query profile stock
   * - ``LA_DP_query_profile_stock_list()``
     - Query profile stock list

Linux Specific Functions
-------------------------

.. list-table:: Linux Specific Functions
   :widths: 70 90
   :header-rows: 1
   :class: large

   * - Function
     - Description
   * - ``LA_Config_linux_tty_prefix()``
     - Configure Linux TTY prefix

.. note::
     For detailed function parameters and return values, please refer to the ``nuSIM_LA.h`` header file.
     The demo code provides examples of how to implement these processes in your own application. You can refer to the demo.c file for detailed implementation examples.

Device Detection    
========================

The device detection process on Linux systems involves the following steps:

1. Enumerate available COM ports
2. Open a COM port connection
3. Check device connection status

Example code for device auto detection:

.. code-block:: c

   int detect_device(LA_COM_uart_fptr pfun)
   {
       // Some code here for variable initialization
       ...

       /*
       ** auto detect mode, we need to config the tty device name prefix, otherwise we have to scan all the tty devices under /dev/.
       ** send AT command to each device and if it responses ok then we consider it is a valid device.
       */
       LA_Config_linux_tty_prefix(g_LAConf.tty_prefix);

       // Enumerate available COM ports
       ret = LA_COM_enum(port_list, sizeof(port_list));
       if(ret != LA_OK) {
           return ret;
       }

       for (int i = 0; i < sizeof(port_list); i++) {
           // Open a COM port connection
           ret = LA_COM_open(port_list[i], 115200, &handle, pfun);
           if(ret != LA_OK) {
               return ret;
           }
       }

       return ret;
   }


For manual detection, you can set the auto_detect to 0 and configure the port list in configuration file.

Initialization Process
========================

The initialization process on Linux systems involves the following steps:

1. System Environment Check

   * Verifies the presence of required system libraries
   * Validates the GCC and glibc versions
   * Checks for necessary system permissions (root permission is required)
   * Ensures proper access to device ports

2. Library Loading

   * Loads required dynamic libraries (libnuSIM_LA.so)
   * Initializes system interfaces
   * Configures logging system

3. Application Startup

   * Configures application parameters from LAConf.ini
   * Initializes core components:
     - COM port communication
     - EUM server connection
     - DP server connection
   * Establishes system connections
   * Sets up device monitoring

4. Device Initialization

   * Opens COM port connection
   * Gets device handle
   * Checks device connection status
   * Retrieves device information (IMEI, nuSIM version)
   * Initializes device with EUM server
   * Gets device EID and nuSIM certificate

Example code for device initialization:

.. code-block:: c

   int initialize_per_device_id(int dev_id, LA_COM_uart_fptr pfun)
   {
       // Some code here for variable initialization
       ...
       
       // Check if device already has nuSIM certificate
       memset(&tmp_nuSIM_info, 0, sizeof(es_info_t));
       if (0 == LA_DEV_get_nusim_cert(g_nusim_dev_handle[dev_id], tmp_nuSIM_info.cert, 
           sizeof(tmp_nuSIM_info.cert), pfun)) {
           printf("Device [%d] already installed nusim cert.\n", dev_id);
           return 0;
       }

       // Get device IMEI
       ...
       LA_DEV_get_imei(g_nusim_dev_handle[dev_id], req_init_data.imei, 
           sizeof(req_init_data.imei), pfun);

       // Request initialization data from EUM server
       ret = LA_PS_req_init_data(1, &req_init_data);
       if(LA_OK == ret) {
           // Initialize device with EUM server data
           // the response data contains the eid
           LA_DEV_initialize(g_nusim_dev_handle[dev_id], NUSIM_CAPABILITY, 
               &req_init_data, &rsp_init_data, pfun);

           // Get attestation token
           // the attesttoken response will be used for nrf cloud attesttoken verification
           LA_DEV_get_attesttoken(g_nusim_dev_handle[dev_id], rsp_init_data.attesttoken, 
               sizeof(rsp_init_data.attesttoken), pfun);

           // Request nuSIM certificates
           memset(batch_code, 0, sizeof(batch_code));
           ret = LA_PS_request_bulk_nusim_certs(1, &rsp_init_data, batch_code, 
               sizeof(batch_code));
           if(ret != LA_OK) {
               printf("request certs failure ret=%d.\n", ret);
               return ret;
           }

           // Blocking wait for certificate generation (while loop)
           ...
               LA_PS_query_nusim_certs_status(batch_code, &total_count, 
                   &success_count, &failed_count);
           ...

           // Retrieve certificates
           ...
           ret = LA_PS_retrieve_bulk_nusim_certs(batch_code, &count, &tmp_nuSIM_info, 
               k_pub_ci, sizeof(k_pub_ci), cm_cert, sizeof(cm_cert));

           // Personalize device with certificates
           ret = LA_DEV_personalize(g_nusim_dev_handle[dev_id], k_pub_ci, cm_cert, 
               tmp_nuSIM_info.cert, pfun);
           if(ret != LA_OK) {
               printf("personalize failure ret=%d.\n", ret);
               return ret;
           }

           // Verify certificates
           memset(temp_str, 0, sizeof(temp_str));
           LA_DEV_get_nusim_cert(g_nusim_dev_handle[dev_id], temp_str, 
               sizeof(temp_str), pfun);
           if(0 != strcmp(tmp_nuSIM_info.cert, temp_str)) {
               printf("verify nusim cert failure!!\n");
               return -1;
           }
       }

       return ret;
   }

Offline Initialization
------------------------

The library provides offline initialization support through the `LA_DEV_personalize_offline()` function, user can load the personalization data from file or other source without contacting the EUM or DP server.

Example code for offline initialization:

.. code-block:: c

   int initialize_per_device_id_offline(int dev_id, LA_COM_uart_fptr pfun)
   {
       int ret = 0;
       char perso_data[2048];  // Buffer for personalization data

       // Check if device already has nuSIM certificate
       if (0 == LA_DEV_get_nusim_cert(g_nusim_dev_handle[dev_id], temp_str, 
           sizeof(temp_str), pfun)) {
           printf("Device [%d] already installed nusim cert.\n", dev_id);
           return 0;
       }

       // Load personalization data from file or other source
       // The data should contain all necessary certificates and keys
       // perso_data contains the apdu data of the personalization command
       // Contact Redtea for the correct format and content of the personalization data
       if (load_personalization_data(perso_data, sizeof(perso_data)) != 0) {
           printf("Failed to load personalization data\n");
           return -1;
       }

       // Perform offline personalization
       ret = LA_DEV_personalize_offline(g_nusim_dev_handle[dev_id], perso_data, pfun);
       if (ret != LA_OK) {
           printf("Offline personalization failed: %d\n", ret);
           return ret;
       }

       return ret;
   }

.. note::
   For offline initialization, you need to prepare the personalization data in advance. This data should include all necessary certificates and keys required for device initialization. Contact Redtea for the correct format and content of the personalization data.

Profile Loading
=====================

The device must be initialized before profile loading.

1. Setup flow
   
   * Connect to nuSIM and read EID and nuSIM certificate
   * Request encrypted profile from DP server
   * DP server encrypts profile with nuSIM's public key
   * Load encrypted profile to nuSIM
   * nuSIM decrypts and installs profile contents

Example code for profile loading:

.. code-block:: c

   int load_profile_per_device_id(int dev_id, LA_COM_uart_fptr pfun)
   {
       // Some code here for variable initialization
       ...
       
       // Check if device already has profile
       if(0 == LA_DEV_get_iccid(g_nusim_dev_handle[dev_id], temp_str, sizeof(temp_str), pfun)) {
           printf("Device [%d] already installed profile.\n", dev_id);
           return 0;
       }

       // Get device EID and nuSIM certificate
       if (LA_DEV_get_eid(g_nusim_dev_handle[dev_id], tmp_nuSIM_info.eid, 
           sizeof(tmp_nuSIM_info.eid), pfun)) {
           return -1;
       }

       if (LA_DEV_get_nusim_cert(g_nusim_dev_handle[dev_id], tmp_nuSIM_info.cert, 
           sizeof(tmp_nuSIM_info.cert), pfun)) {
           return -1;
       }

       // Get CM certificate
       if (LA_DEV_get_cm_cert(g_nusim_dev_handle[dev_id], cm_cert, sizeof(cm_cert), pfun)) {
           return -1;
       }

       // Query available profiles
       LA_DP_query_profile_stock(g_LAConf.dp_refInfo1, g_LAConf.dp_refInfo2, 
           g_LAConf.dp_refInfo3, &profile_num);
       if(profile_num <= 0) {
           return -1;
       }

       // Get encrypted profile
       ret = LA_DP_get_enc_profile(g_LAConf.rootKeyID, cm_cert, tmp_nuSIM_info.eid, 
           tmp_nuSIM_info.cert, 1, g_LAConf.dp_refInfo1, g_LAConf.dp_refInfo2, 
           g_LAConf.dp_refInfo3, &profile_info);
       if(ret != LA_OK) {
           return ret;
       }

       // Load profile to device
       ret = LA_DEV_load_profile(g_nusim_dev_handle[dev_id], &profile_info, 
           &dp_auth, iccid, sizeof(iccid), pfun);
       if(ret != LA_OK) {
           return ret;
       }

       return ret;
   }

2. Verification

   * Verify profile installation status
   * Check device operational status
   * Monitor system logs for any errors
   * Validate device connectivity

.. note::

   Make sure to verify the GCC and Glibc versions before running the application to ensure compatibility.
