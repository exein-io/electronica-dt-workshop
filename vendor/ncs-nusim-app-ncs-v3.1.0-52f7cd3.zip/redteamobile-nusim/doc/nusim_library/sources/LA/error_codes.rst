Error Codes
===========

This document lists all nuSIM os error codes that may be returned by the nuSIM Library functions, as defined in the nuSIM_LA.h file, the base error code **LA_COS_ERROR_BASE is -3000**.
The error code will be combined with the base error code to form the final error code, for example, if the error code is 100, the final error code will be **LA_COS_ERROR_BASE - 100**.

.. note::
    The error code definitions are apply to the library both for Windows and Linux.


General Error Codes
--------------------

.. list-table:: General Error Codes
   :widths: 75 90
   :header-rows: 1
   :class: large

   * - Error Code
     - Description
   * - ``UNKNOW_ROOT_KEY_ID (100)``
     - Unknown root key ID
   * - ``WRONG_NUSIM_CERT (101)``
     - Invalid nuSIM certificate
   * - ``CM_CERT_NOT_AVAILABLE (102)``
     - CM certificate not available
   * - ``VERF_REC_CM_CERT_FAILED (103)``
     - CM certificate verification failed
   * - ``EID_NOT_MATCH_NUSIM_CERT (104)``
     - EID does not match nuSIM certificate

Profile Related Error Codes
-----------------------------

.. list-table:: Profile Related Error Codes
   :widths: 75 90
   :header-rows: 1
   :class: large

   * - Error Code
     - Description
   * - ``NO_PROFILE (301)``
     - No profile available
   * - ``INVALID_REFINFO1 (302)``
     - Invalid reference info 1
   * - ``INVALID_REFINFO2 (303)``
     - Invalid reference info 2
   * - ``INVALID_REFINFO3 (304)``
     - Invalid reference info 3

nuSIM Operation Error Codes
-----------------------------

.. list-table:: nuSIM Operation Error Codes
   :widths: 75 90
   :header-rows: 1
   :class: large

   * - Error Code
     - Description
   * - ``TECHNICAL_ERROR (402)``
     - Technical error
   * - ``VERSION_NOT_SUPPORTED (403)``
     - Version not supported
   * - ``NOT_YET_READY (404)``
     - Operation not ready
   * - ``INVALID_REFERENCE_ID (405)``
     - Invalid reference ID
   * - ``NUM_OF_REQ_PROFILE_TOO_HIGH (406)``
     - Number of requested profiles too high
   * - ``GENERATE_KEYPAIR_FAIL (407)``
     - Failed to generate key pair
   * - ``NUSIM_SIGNATURE_FAIL (408)``
     - nuSIM signature verification failed
   * - ``NUSIM_NOT_INITIALIZE (501)``
     - nuSIM not initialized
   * - ``SECRET_KEY_ERROR (502)``
     - Secret key error
   * - ``MAC_FAILURE (503)``
     - MAC verification failed
   * - ``PROFILE_ERROR (504)``
     - Profile error
   * - ``PROFILE_ALREADY_LOADED (505)``
     - Profile already loaded
   * - ``NUSIM_KPUBCI_UNAVAILABLE (506)``
     - nuSIM CI public key unavailable
   * - ``NUSIM_KPUBDP_SIGN_FAIL (507)``
     - nuSIM DP public key signature verification failed
   * - ``NUSIM_EKPUBDP_SIGN_FAIL (508)``
     - nuSIM encrypted DP public key signature verification failed
   * - ``NUSIM_KPUBCI_UNMATCH (509)``
     - nuSIM CI public key mismatch

nuSIM Response Error Codes
----------------------------

.. list-table:: nuSIM Response Error Codes
   :widths: 75 90
   :header-rows: 1
   :class: large

   * - Error Code
     - Description
   * - ``NUSIM_RES_ERR_DATA_FORMAT_INVALID (701)``
     - Invalid data format
   * - ``NUSIM_RES_ERR_COMMNAD_NOT_SUPPORT (702)``
     - Command not supported
   * - ``NUSIM_RES_ERR_SECURE_CHECK_FAILED (703)``
     - Security check failed
   * - ``NUSIM_RES_ERR_MEMORY_FAILED (704)``
     - Memory operation failed
   * - ``NUSIM_RES_ERR_NO_PROFILE (705)``
     - No profile available

EUM Server Error Codes
-----------------------

.. list-table:: EUM Server Error Codes
   :widths: 75 90
   :header-rows: 1
   :class: large

   * - Error Code
     - Description
   * - ``4056``
     - The access key and secret does not exist.
   * - ``4063``
     - EUM verify signature failed, The CSR from device is invalid or unusable.
   * - ``4064``
     - nRF Cloud attestation verification failed.
   * - ``40641``
     - EUM verify attestation failed, the EID is not same as the EID in the request.
   * - ``4065``
     - Batch code is empty as the EUM is still in the process of generating the batch code, you can try again later within 1 minute.
   * - ``4067``
     - EUM failed to verify CSR signature, the CSR from device is invalid or unusable.
   * - ``4068``
     - Invalid IMEI.
   * - ``10001``
     - The access key and secret does not match with the EUM due to the CM is not registered for this access key.
   * - ``10002``
     - Request is not supported.
   * - ``10007``
     - Maximum issued certificate quantity is reached, please contact Redtea.

     