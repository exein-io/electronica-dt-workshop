.. _la_user_guide:

Initialization and Loading Application (IALA)
###############################################

The IALA combines an Initialization Application for nuSIM intialization and a Loading Application profile loading. There are two versions of the IALA, one for Windows and one for Linux.

.. toctree::
   :maxdepth: 1
   :caption: Subpages:

   win
   linux
   error_codes
