.. _la_wintool_guide:

IALA for Windows
################

Introduction
===============

Purpose
-----------

This part of the document shall explain the usage of the Redtea nuSIM Initialization and Loading Application (IALA) for Windows in combination with Nordic nRF91 Series LPWA radio modules.

Prerequisites
-----------------

Microsoft .NET Framework 4.8

Installation
==============

Run the Redtea nuSIM IALA setup wizard and follow the indicated steps. (If you have an older version already installed, please remove it beforehand.) The setup wizard will install the nuSIM IALA in the desired folder, ready for use.

.. image:: ./pics/install_1.png
   :width: 35%
   :alt: 

Choose the path where the app will be installed.

.. image:: ./pics/install_2.png
   :width: 35%
   :alt:

Choose 'Next' in latter options and you will complete the installation:

.. image:: ./pics/install_3.png
   :width: 35%
   :alt: 

Operation
==============

Step of usage
--------------

The standard operation process is "Detect Ports" -> "Initialization"-> "Profile Loading".

.. image:: ./pics/mainwindow.png
   :width: 55%
   :alt: 

Before start the process, you may check all the neccesary information/credentials are correctly configured in :ref:`Configuration <Configuration>`.

- **Step 1: Detect Ports:** Used for detecting the connected nuSIM devices. For every connected device it will
  read the nuSIM OS version and the IMEI of the device, plus - depending on the state of the device - the EID of the nuSIM and the ICCID of the present profile. The information is 
  displayed in the respective channel window CH1 to CH4. The EID will only be displayed for an initialized nuSIM and the ICCID will only be dispayed when a profile is loaded, The Status indecates the life status of the nuSIM device.

- **Step 2: Initialization**: When this button is clicked, the IA will request the EID and
  other initialization data from the Redtea PS Server and write everything to the device. The channel window for each connected device will additionally display the EID.

- **Step 3: Profile Loading:** When this button is clicked, the LA will download
  profiles from the DP Server and write them to the
  devices. Once the process is complete successfully, the ICCID of the
  profiles will show up in the channel windows.

The IALA stores each downloaded profile in the "downloads" folder. The files are named "{IMEI}_{DATETIME}.json". The DP authentication information will be stored in the same folder, in the file named "DP_Auth.json". The information from these files can be used to manually load the profile with offline mode.

.. image:: ./pics/downloads.png
   :width: 55%
   :alt: Advanced

nuSIM Status
-----------------

The nuSIM life cycle is the sequence of states that a nuSIM device can be in, it shows in the status column of the Channel windows.

Uninitialized
**************

The uninitialized state is the initial state of a nuSIM device where neither EID nor nuSIM certificates have been written to the device, this state is also called out of the box state.

.. image:: ./pics/status_uninitialized.png
   :width: 45%
   :alt: 


Initialized
**************

The initialized state is the state of a nuSIM device where EID and nuSIM certificates have been written to the device, the nuSIM will need to install the profile before it can be used.

.. image:: ./pics/status_initialized.png
   :width: 45%
   :alt: 


Profile Loaded
**************

The profile loaded state is the state of a nuSIM device where a profile has been loaded to the device, the nuSIM is now ready to be used, note that before profile loading, the nuSIM must be initialized first.

.. image:: ./pics/status_profile_loaded.png
   :width: 45%
   :scale: 80%
   :alt: 

Advanced
===================

The **Advanced** section in the sidebar is only shown when **Offline Mode** is enabled in the **System -> Configuration** page.

.. image:: ./pics/en_offline_mode.png
   :width: 75%
   :alt: 

Offline Mode
--------------

The offline mode is used for manually installing nuSIM certificates and 
load nuSIM profiles when suitable test data is at hand. It is usually used by 
developers for test purposes.

.. image:: ./pics/offline_window.png
   :width: 85%
   :alt: 

Enter the target COM port for the device and the data elements as required, 
then click **Initialize** or **Load Profile** to execute. Here are example screenshots:

**Initialize:**

.. image:: ./pics/offline_initialize.png
   :width: 85%
   :alt: 

Note: For offline initialization, please make sure that your device firmware is built with the corresponding 
kconfig option as defined in chapter 2, Integration Guide (section :ref:`OffLine Mode <offline_mode>`).

**Load Profile:**

.. image:: ./pics/offline_profileloading.png
   :width: 85%
   :alt: 

Note: For offline profile loading, suitable test data that corresponds to the initialization must be obtained from a nuSIM DP.

HTTP Proxy
--------------

The HTTP Proxy is used to proxy the nuSIM IALA requests to the remote EUM server and the nuSIM DP server, it is used when the nuSIM IALA is not directly connected to the internet.
You need to configure the HTTP Proxy parameters as required, the default is not using the HTTP Proxy.

.. image:: ./pics/http_proxy.png
   :width: 85%
   :alt: 

Information
=================

The **Information** menu item allows to get information about your 
profile stock at the nuSIM DP and to generate a device information report.

.. image:: ./pics/info_list.png
   :width: 55%
   :alt: 

Profile Stock
-----------------

Displays information about the number of nuSIM profiles 
available for download at the DP for a given RefInfo 1/2/3 combination. The 
"Configuration" page (see below) must contain the correct data including valid 
RefInfo 1/2/3 data. 

Note: A complete view on all stocks available to a particular LA may require 
multiple stock requests with different RefInfo 1/2/3 data. The values and meaning 
for RefInfo 1/2/3 are defined by the respective MNO. For example, if a customer 
has placed two profile orders at the MNO and RefInfo 3 represents the order number, 
then two stock requests with different RefInfo 3 (= order number) are required to 
get the total number of available profiles from both orders.       

Device Report
-----------------

Generates a CSV file in the "reports" folder. 

.. image:: ./pics/report_folder.png
   :width: 55%
   :alt: 

The file contains the relation between each device IMEI, nuSIM OS Version & EID and profile ICCID. This 
can help the user to identify the device and the profile that is loaded on it. The CSV file contains the 
following columns: 

- **IMEI**: The IMEI of the device
- **OSver**: The nuSIM OS version of the device
- **EID**: The EID of the nuSIM
- **ICCID**: The ICCID of the profile

.. image:: ./pics/device_report.png
   :width: 55%
   :alt: 

Logs
------

The IALA application automatically generates detailed log files for tracing and stores them in the logs folder.

.. image:: ./pics/logfolder.png
   :width: 55%
   :alt: 

There are three types of log files per date & time:

- **APP\_{DATE}.log** -> the main application logs

- **CH\_{Index}\_{DATE}.log** -> the logs of each channel

- **Dll\_{DATE}.log** -> the DLL logs of the library.

Three commands are available in the "Logs" section: 

.. image:: ./pics/log_options.png
   :width: 40%
   :scale: 80%
   :alt: 

- **View Folder:** The command will open the log folder in the file explorer, it will help you to open the log folder quickly.

- **Pack Logs:** The command will pack the log files into a zip file.

- **View Latest Log:** The command will open the latest DLL log file with MS Notepad.

System
=============

This section is used to check the system information of the IALA application and configure the application.

.. _Configuration:

Configuration
----------------

In the Left navigation bar, click on "Configuration":

A pop-up window will appear:

.. image:: ./pics/conf_window.png
   :width: 35%
   :alt: 

Make sure you configure each item carefully as explained in the following table. For tests or smaller production volumes it is recommended to use the 'Proxy-Mode' for access to the nuSIM Data preparator through Redtea proxy sever. This configuration must be aligned with the mobile operator. If you are not using the 'Proxy Mode', please allow some lead time to obtain your individual LA TLS certificate.

.. table:: Configuration Items
   :widths: 20 30 50
   :align: left

   +------------------+---------------------------------------+---------------------------------------------------------+
   | Section          | Items                                 | Description                                             |
   +==================+=======================================+=========================================================+
   | EUM Server       | Server Address / Access Key /         | Access credentials to EUM server. Please contact        |
   |                  | Access Secret                         | **Redtea** to get suitable values.                      |
   +------------------+---------------------------------------+---------------------------------------------------------+
   | DP Server        | Server Address / Root Key ID          | Provided by the selected mobile network operator.       |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | Use Proxy                             | If selected, the Redtea PS Server acts as a proxy for   |
   |                  |                                       | profile download. Configuration items marked with (*)   |
   |                  |                                       | are not required in this case, but section 'LA Proxy'   |
   |                  |                                       | must contain valid data.                                |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | Path to CI Cert * / Path to LA Cert * | These entries belong to the LA client TLS certificate   |
   |                  | / Path to LA Cert Key File * /        | when 'Use Proxy' is not selected, i.e. when the DP is   |
   |                  | Password of Key File *                | directly accessed. Please contact the mobile network    |
   |                  |                                       | operator. These entries are not needed when 'Use        |
   |                  |                                       | Proxy' is selected.                                     |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | RefInfo 1/2/3                         | Reference data to identify a certain profile order in   |
   |                  |                                       | the DP. Provided by the mobile network operator.        |
   +------------------+---------------------------------------+---------------------------------------------------------+
   | Serial Ports     | Port Auto Detect                      | The IALA can connect up to four devices in parallel,    |
   |                  |                                       | each through a dedicated channel. If 'Port Auto Detect' |
   |                  |                                       | is selected, the channels are automatically assigned to |
   |                  |                                       | COM-Ports that have a device connected.                 |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | Channel Port 1/2/3/4                  | If 'Port Auto Detect' is not selected: Manual assignment|
   |                  |                                       | of IALA channels to COM-Ports.                          |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | COM Baudrate                          | The UART speed for the Com-Port, the default is 115200. |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | AT Line Ending                        | CR/CRLF/LF line ending for AT commands.                 |
   +------------------+---------------------------------------+---------------------------------------------------------+
   | LA Proxy         | Server Address / Access Key /         | Access credentials to Readtea Proxy server. Please      |
   |                  | Access Secret                         | contact **Redtea** to get suitable values.              |
   +------------------+---------------------------------------+---------------------------------------------------------+
   | Advanced         | Offline Mode                          | If selected, allows initialization and profile loading  |
   |                  |                                       | with local data for test purposes.                      |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | HTTP Proxy                            | If selected, the HTTP Proxy will be used to proxy the   |
   |                  |                                       | nuSIM IALA requests to the remote EUM server and the    |
   |                  |                                       | nuSIM DP server.                                        |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | Server address                        | The address of the HTTP Proxy.                          |
   |                  |                                       | The default is empty.                                   |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | User Name                             | The user name of the HTTP Proxy.                        |
   |                  |                                       | The default is empty.                                   |
   |                  +---------------------------------------+---------------------------------------------------------+
   |                  | Password                              | The password of the HTTP Proxy.                         |
   |                  |                                       | The default is empty.                                   |
   +------------------+---------------------------------------+---------------------------------------------------------+  

**'Reset Default'** brings back the default settings and 'Save All' will save any changes with immediate effect.  

A mouseover on the configuration items will also show appropriate help information.

.. image:: ./pics/conf_tips.png
   :width: 60%
   :alt:


About
-----------

Version Info
****************

Displays the software version information:

.. image:: ./pics/about.png
   :width: 55%
   :alt: 

Error Codes
****************

In order to help you to understand the error codes, we provide the error codes reference, you can search the error codes by the error code or the error description:

.. image:: ./pics/error_codes.png
   :width: 55%
   :alt: 

