.. _index:

nuSIM for Nordic Semiconductor nRF91 Series
############################################

.. only:: html

   Overview
   --------

   This is the nuSIM solution for NCS where you begin building nuSIM applications with Nordic Semiconductor nRF91 Series devices.

   The nuSIM solution is a software stack that provides the necessary components (library - built on top of the NRF Connect SDK (NCS)) to create a nuSIM application. It includes the nuSIM application, the Initialization Application (IA), and the Loading Application (LA).

   The nuSIM application is responsible for managing the nuSIM profile, while the IA and LA are used for initializing and loading the profile, respectively.

   Read more about the detailed information of the project in the following sections.

.. toctree::
   :maxdepth: 5
   :caption: Contents
   :glob:

   Introduction
   Integration/index
   LA/index
   revision
