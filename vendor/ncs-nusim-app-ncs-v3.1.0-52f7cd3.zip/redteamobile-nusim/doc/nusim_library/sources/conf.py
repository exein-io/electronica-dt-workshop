# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

project = 'nuSIM for Nordic nRF91xx'
copyright = 'redteamobile.com'
author = 'RedTeaMobile'
release = '2.7.8'

# -- LaTeX configuration ---------------------------------------------------
latex_elements = {
    'papersize': 'a4paper',
    'pointsize': '11pt',
    'extraclassoptions': 'openany,oneside',
    'babel': '\\usepackage[english]{babel}',
    'figure_align': 'H',
    'preamble': r'''
        \usepackage{float}
        \usepackage{booktabs}
        \usepackage{array}
        \usepackage{longtable}
        \usepackage{enumitem}
        \setlistdepth{9}
        \setcounter{tocdepth}{3}
    ''',
}

html_static_path = ['_static']
html_css_files = [
    'custom.css',
]

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = []

templates_path = ['_templates']
exclude_patterns = ['_build_sphinx', 'Thumbs.db', '.DS_Store']

# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = "sphinx_rtd_theme"

from docutils import nodes
from docutils.parsers.rst import roles
import re

def escape_latex(text):
    return re.sub(r'([#$%&_{}])', r'\\\1', text)

def colored_bold_role(name, rawtext, text, lineno, inliner, options={}, content=[]):
    color = name

    html = f'<strong style="color:{color}">{text}</strong>'

    safe_text = escape_latex(text)
    latex = f'\\textbf{{\\textcolor{{{color}}}{{{safe_text}}}}}'

    node_html = nodes.raw('', html, format='html')
    node_latex = nodes.raw('', latex, format='latex')

    return [node_html, node_latex], []

for color in ['red', 'green', 'blue', 'brown', 'black', 'yellow', 'orange']:
    roles.register_local_role(color, colored_bold_role)

latex_elements = {
    'preamble': r'\usepackage{xcolor}',
}
