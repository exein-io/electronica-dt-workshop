.. _debug_guide:

Debug and Test
##################

Get nuSIM Information
-------------------------

Connect your nRF9151 DK (nRF9151 as an example) and open Serial Terminal to get the nuSIM OS
version information through a UART interface and make sure that you received simimiar version information to confirm that the
integration is successful:

.. image:: ./pics/image4.png
   :alt: 

Switch between nuSIM and physical SIM
-----------------------------------------

The nuSIM service starts successfully does not means that the modem is
using nuSIM, you need to use this AT command to activate nuSIM:

**AT%CSUS=2**

Switch back to physical SIM:

**AT%CSUS=0**

**Note: Set this option before 'AT+CFUN=1'.**

For more info, please check the nRF91xx AT commands reference guide.

Disable MCUBoot
-------------------

To debug the project without the MCUBoot, you can disable the MCUBoot in
prj.conf:

**CONFIG_BOOTLOADER_MCUBOOT=n**

And you need to remove the child_image folder under the source code
directory, and change the PM partition size of TFM in
overlay-nusim.conf:

.. image:: ./pics/image6.png
   :alt: 

.. _recover-from-locked-state-and-reflash:

Recover from Locked State and Reflash
-----------------------------------------

When the device is in locked state, if you cannot flash the new image
due to a key mismatch or other reasons, or if you want to erase the
whole flash memory, you can use the nrfutil command with recover
option. Note that this command will erase the whole flash memory:

.. code-block:: sh

   nrfutil device recover --family nrf91

Profile Reprovisioning
--------------------------

For security reasons, the nRF91xx nuSIM OS does not support profile
reprovision which means once the nuSIM profile is loaded, you will be
unable to load a new profile by simply overwriting the old one.

Therefore, before loading a new profile, you will have to erase the
whole flash by running the ``nrfutil device recover`` command (defined in :ref:`recover-from-locked-state-and-reflash`) and reflash the
firmware.

.. _la-appliaction:

Initialization and Profile Loading
-----------------------------------

Redtea provides a nuSIM Initialization and Profile Loading Application (IALA) for nuSIM initialization
and profile loading, it is in the tools folder and the user guide is in
docs folder.

The IALA uses a UART interface for sending AT commands and receiving
responses. For further support and information, please contact Redtea.

.. image:: ./pics/image7.png
   :alt: 

Modem Trace
----------------

Add '\ **CONFIG_NRF_MODEM_LIB_TRACE=y**\ ' to the Prj.conf and add the modem
trace UART snippet to build the project with below commands (nRF9151 as an example):

.. code-block:: sh

   west build -S nrf91-modem-trace-uart -b nrf9151dk/nrf9151/ns --sysbuild -p -- -DEXTRA_CONF_FILE='../../overlay-nusim.conf'

Note that the above build command does not work for all projects, to add
your own modem trace backend, please refer to the sample project
**modem_trace_backend** located in the 'nrf/samples/cellular' and you
can also get more detail information
`here <https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/libraries/modem/nrf_modem_lib/nrf_modem_lib_trace.html>`_.
