.. _nusim_at:

AT Commands
##################

Here are some useful AT commands for debugging and testing purposes.
Please refer to the Redtea nuSIM AT commands specification for a full
description.

.. list-table::
   :widths: 25 35 40
   :header-rows: 1

   * - CMD
     - Description
     - Comment         
   * - AT+NUSIM=0/1
     - Enable or disable nuSIM
     - NOT used on nRF91xx,please check the `AT commands <#41-switch-between-nusim-and-physical-sim>`_ to switch between nuSIM and external physical SIM.
   * - AT+NUSIM=2
     - Perform warm reset to the OS
     - The command will call AT+CFUN=0 and reset the OS System.
   * - AT+NUSIM=3
     - Perform cold reset to the OS.
     - The command will call AT+CFUN=0 and reset the OS System.   
