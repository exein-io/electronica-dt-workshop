.. _add_project_guide:

Add nuSIM into your project
##############################

There are two main scenarios for integrating nuSIM:

- **Scenario 1: Provisioning a Blank Device**

   Use this method if your device is delivered without a nuSIM profile. (e.g. regular nRF9151, nRF9160)
  
   - Reference:
      - Use the samples/basic project as a guide.
   - Process:
      - Build your application with the nuSIM overlay.
      
        Note: Add the overlay-nusim.conf file to your build command to enable the necessary features.

        .. code-block:: sh

            west build -b nrf9151dk/nrf9151/ns -- -DEXTRA_CONF_FILE='../../overlay-nusim.conf'

      - Flash the full firmware image to the blank device.
      - Initialize and load profile using the IALA . (see :ref:`section 3 <la_user_guide>` for more details)

- **Scenario 2: Updating a Pre-Provisioned Device (e.g. a nRF9151 DK that is pre-provisioned or pre-provisioned module)**

    You can use this method when updating firmware on a device that already has a nuSIM profile installed.

    .. warning::
        A chip erase or full flash will permanently delete the nuSIM profile. You must perform a safe, partial flash. For more details on how to perform this operation correctly, refer to the :ref:`data-protection-safe-flashing` section.

    - Reference:
       - Use the samples/udp project as a guide.
    - Process:
       - Build your application with the nuSIM overlay.

         Note: Add the overlay-nusim.conf file to your build command to enable the necessary features.

         .. code-block:: sh

            west build -b nrf9151dk/nrf9151/ns -- -DEXTRA_CONF_FILE='../../overlay-nusim.conf'

       - Flash only the application and bootloader images.
       - DO NOT erase or change the tfm-storage or tfm-its partition layout (see :ref:`Static partitions <static_partitions>` for more details).

Kconfig
-----------

These Kconfig options need to be enabled in your project:

The following option enables nuSIM library for your application and **it is default enabled when overlay config file is attached**:

.. code-block:: sh

   CONFIG_LIB_NUSIM=y

The following option enables nuSIM AT command support:

.. code-block:: sh

   CONFIG_LIB_NUSIM_AT=y

.. note::
   The option **CONFIG_LIB_NUSIM_AT** is by default enabled as the nuSIM device needs a serial AT interface to run initialize and profile loading.

   - Use cases:

      - For nuSIM provisioning if this is not already done.
      - Use of AT+NUSIM for development/debugging purposes.

   - If nuSIM is already pre-provisioned, it is not recommended to enable this option as the nuSIM AT interface is only needed for nuSIM provisioning.

   The following two steps are recommended during device manufacturing if your application does not need a serial interface:

      * With  **CONFIG_LIB_NUSIM_AT** enabled, flash the firmware to the device, then provision it through the AT command interface.
      * With **CONFIG_LIB_NUSIM_AT** disabled, flash the firmware to the device with provisioning data kept (see :ref:`data-protection-safe-flashing` section for safe flashing).

Initialize Interface
------------------------

The following picture describes the nuSIM architecture in nRF91xx:


.. image:: ./pics/image2.jpg
   :alt: 


The nuSIM initialize contains three functions: initialize interface for
nuSIM OS, AT handler, SoftSIM handler.

The initialize interfaces for the OS will be called automatically during
system starts, the only thing you need to do is to call
**nrf_modem_lib_init()** to initialize modem lib in your own application
and it is called only once in your application.

Failure is possible for nuSIM initialize and here are the error descriptions during nuSIM initialize which you may
encounter:
 
* **Error code descriptions for rt_cos_api_init()**

.. list-table::
   :widths: 15 35 50
   :header-rows: 1

   * - Error Code
     - Error String
     - Comment
   * - -100
     - Invalid command type
     - Internal APDU error codes for nuSIM OS, it should not happen during rt_cos_api_init().
   * - -101
     - IO ID error
     - 
   * - -102
     - IO handle error
     - 
   * - -103
     - Receive data error
     - 
   * - -104
     - Data Length error
     - 
   * - -105
     - Data checksum error
     - 
   * - -106
     - Data header error
     - 
   * - -107
     - APDU data error
     - 
   * - -108
     - Invalid TF-M SID
     - The SID of nuSIM is defined to 0xFA, please do not change the value, you will not need to change it.
   * - -109
     - Get TFM version Info failure
     - These error codes indicates that there are something doesn't work for the TFM partition service, the partition service may not be ready, and you need to check the tfm configurations or the whole implementation of the partition service.
   * - -110
     - PSA connect TFM service failure
     - 
   * - -111
     - PSA call send message failure
     - 



* **rt_nusim_softsim_init()**\ :

the function calls k_thread_create() and nrf_modem_softsim_req_handler_set() to create the separate thread for softsim APDU handling.
Failure may happen when calling nrf_modem_softsim_req_handler_set(), you will need to check the modem lib errors for specific reason.


.. _sysbuild_config:

Sysbuild
------------

Add ``sysbuild.conf`` in the root directory and add these configuration options:

.. code-block:: sh

    SB_CONFIG_BOOTLOADER_MCUBOOT=y
    SB_CONFIG_APPROTECT_USE_UICR=y
    SB_CONFIG_BOOT_SIGNATURE_KEY_FILE="${APPLICATION_CONFIG_DIR}/sysbuild/mcuboot/mcuboot_priv.pem"

MCUBoot
-----------

Sysbuild Configs
^^^^^^^^^^^^^^^^^^

According to mandatory security requirements, MCUBoot **must** be enabled to work as an immutable bootloader. Sysbuild is used for MCUBoot build with customized configurations as given in prj.conf. 
The following files are needed in the sysbuild directory:

.. list-table::
   :header-rows: 1

   * - Config file
     - Comment      
   * - prj.conf
     - Required MCUBoot configurations.        
   * - mcuboot_priv.pem
     - The key is used both by the build system and by the bootloader to verify the application signature. 

.. _mcuboot_config_options:

Configuration
^^^^^^^^^^^^^^

The following MCUBoot configurations are required for nuSIM security compliance and must be added to the prj.conf file:

.. code-block:: sh

   # Enable fault injection hardening
   CONFIG_BOOT_FIH_PROFILE_MEDIUM=y

   # Enable ECDSA P256 signing/verification
   CONFIG_BOOT_SIGNATURE_TYPE_ECDSA_P256=y
   CONFIG_BOOT_SIGNATURE_TYPE_RSA=n

   # Downgrade prevention
   CONFIG_MCUBOOT_DOWNGRADE_PREVENTION=y

You must also set the MCUboot private key path (SB_CONFIG_BOOT_SIGNATURE_KEY_FILE) in the :ref:`Sysbuild <sysbuild_config>` configuration.

Key generation
^^^^^^^^^^^^^^^^^^^^

You can use OPENSSL to generate the key file or use other ways of key
generation as described
`here <https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/bootloaders_dfu/mcuboot_nsib/bootloader_signature_keys.html#id6>`_.
Note that it is highly recommended to use the ECDSA key type:

.. code-block:: sh

   openssl ecparam -name prime256v1 -genkey -noout -out mcuboot_priv.pem

Accordingly, the key type ECDSA should be configured in the :ref:`MCUBoot configuration <mcuboot_config_options>`:

.. code-block::

   CONFIG_BOOT_SIGNATURE_TYPE_ECDSA_P256=y
   CONFIG_BOOT_SIGNATURE_TYPE_RSA=n

Configuration Verification
^^^^^^^^^^^^^^^^^^^^^^^^^^^

The required configurations will be verified later during the nuSIM
initialization process when the corresponding configurations will be
read from the device and sent together with the initialization request
(request for nuSIM certificate) to the Redtea Server. If the
verification fails, the product will be considered as **Security
Non-Certified** and the request will be **rejected**.

.. _static_partitions:

Static partitions
---------------------

Static configured partitions is required for FOTA and data security, The
partitions need to be static defined are listed as below:

+----------------------+-------------------------------------------------+
|Partition name        | Comment                                         |
+======================+=================================================+
| tfm-storage          | Storage partition for tfm.                      |
+----------------------+-------------------------------------------------+
| tfm-its              | Part of tfm-storage, used for nuSIM key data    |
|                      | storage and the data should be kept after FOTA. |
+----------------------+-------------------------------------------------+
| tfm_otp_nv_counters  | Part of tfm-storage.                            |
+----------------------+-------------------------------------------------+

A static pm_static.yml file is needed to define the partitions, see section :ref:`tfm-storage` and :ref:`data-protection-safe-flashing` for more details.

.. _tfm-storage:

TFM Storage
---------------

The size of 32KB is needed for tfm storage, the nuSIM OS utilizes ITS
for data storage and the required size is 24KB, UIDs from 1 to 32 are
reserved for nuSIM.

.. _data-protection-safe-flashing:

Data Protection and Safe Flashing
------------------------------------

The nuSIM area stores cryptographic keys and other data essential for the SIM functionality of your device. If erased or overwritten, all stored data is lost, and re-provisioning is required, involving dedicated tools and additional effort.

Required Static Partitions
^^^^^^^^^^^^^^^^^^^^^^^^^^^
Add these definitions to your pm_static.yml:

+----------------------+------------+---------+----------------------------------------+
|Partition             | Address    | Size    | Purpose                                |  
+======================+============+=========+========================================+
| tfm-storage          | 0xF8000    | 0x8000  | TF-M storage (incl. nuSIM)             |
+----------------------+------------+---------+----------------------------------------+
| tfm-its              | 0xF8000    | 0x6000  | nuSIM internal storage                 |
+----------------------+------------+---------+----------------------------------------+

.. important::

  - Adjust addresses if needed, but these are recommended guidelines. Do not overlap with code or other data.
  - :red:`Never erase or modify these areas once provisioned. Doing so will permanently delete the nuSIM profile`.


Flashing and Updating Guidelines
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. caution::
  The nuSIM profile is stored in a protected, non-volatile memory region on the device. Performing a chip erase, device recover, or full-flash erase will permanently delete the nuSIM profile, rendering the device unable to connect. Follow these guidelines carefully to prevent data loss.

Core Principle: Use Partial Erase Only
"""""""""""""""""""""""""""""""""""""""
The key to safe flashing is to only erase and program the memory regions that are being updated (e.g., the application, MCUBoot). The partitions containing the nuSIM profile, specifically **tfm-storage** and **tfm-its**, must never be erased or overwritten during a firmware update.

Tool-Specific Flashing Instructions
"""""""""""""""""""""""""""""""""""""""
Different flashing tools have different default behaviors. Use this table as a reference for the recommended tools and settings.

.. tabularcolumns:: L L L

.. list-table:: Flashing Tool Guidelines
   :header-rows: 1
   :widths: 21 28 66
   :align: left
   :class: nonumbered

   * - **Tool**
     - **Default Behavior**
     - **Required Action**
   * - west flash
     - :green:`Safe by Default`. Only the flash ranges touched by the new firmware are erased.
     - :black:`Recommended`. No extra options needed.
   * - nrfutil device program
     - :orange:`DANGEROUS`. Erases the entire chip by default.
     - :black:`Must provide`:  
       ``nrfutil device program --firmware app.hex --options chip_erase_mode=ERASE_RANGES_TOUCHED_BY_FIRMWARE``
   * - pyocd
     - :brown:`POTENTIALLY DANGEROUS`. May trigger automatic "device recovery" (full chip erase).
     - :black:`Use with caution`. Verify scripts/defaults do not trigger chip erase or recovery.
   * - nRF Connect for Desktop Programmer
     - :red:`UNSAFE`. Erases the entire chip by default; no option to limit.
     - :black:`DO NOT USE` for devices with provisioned nuSIM profile.
   * - nRF Connect for Desktop Quick Start
     - :red:`UNSAFE`. Erases the entire chip by default; no option to limit.
     - :black:`DO NOT USE` for devices with provisioned nuSIM profile.
   * - Other
     - `UNKNOWN`.
     - Read the documentation for the tool before use.

General Best Practices
""""""""""""""""""""""""""""
  - Targeted Updates 
        When building and flashing, only include the application and bootloader (e.g., MCUBoot/TFM) images.

  - Verify Partitions
        Before every flash or update, double-check your partition manager configuration (pm.yml or Kconfig) to ensure the nuSIM storage areas are correctly defined and protected, the following command will output a report for validation.

        .. code-block:: sh

            west build -t partition_manager_report

  - Test Before Production
        Always validate your flashing process on a small batch of development devices before deploying it in a mass-production environment.


Samples
-----------

There are two sample projects for reference: basic and udp.

The basic application shows a minimal nuSIM application with MCUBoot, the sample will work with :ref:`la-appliaction` to complete the nuSIM provision.

The udp application demonstrates the most basic cellular application
with nuSIM integrated, nuSIM AT command is disabled in this sample, you have to run nuSIM provisioning with basic sample.

OffLine Mode
-----------------

.. _offline_mode:

The offline mode is used for helping the developer to test the nuSIM
without requesting the nuSIM certs and profiles from remote data server,
the developer can set the data elements with :ref:`la-appliaction` locally to complete the device initialize and
profile loading, note that it is not able to get the initialize data and
profiles from DP through http request when offline mode is enabled.

Enable the following kconfig option to activate the offline mode:

.. code-block:: sh

   CONFIG_LIB_NUSIM_TFM_OFFLINE_ENABLED=y

ROM and RAM size
---------------------

The code size of the nuSIM OS is around 43KB, 5.4KB(5504Bytes) RAM size
is needed.

Stack size for TF-M xuicc partition service is 4KB as defined in the
partition service yaml file in TF-M.

The nuSIM OS works as a partition service in TF-M, and the TF-M
partition size is 192KB (0x30000) with MCUBoot, If MCUBoot is not
enabled, the size is 0x2FE00, The minimal configurations for TF-M are
defined in **overlay-nusim.conf**\ , you can **tweak** the size of the TFM
to get the best utilization of the flash memory according to your own
project.

.. list-table::
   :header-rows: 1

   * - **Type**
     - **With-MCUBoot**
     - **No-MCUBoot**
   * - DEBUG firmware for develop and testing
     - 0x37E00
     - 0x38000
   * - Release Firmware for production
     - 0x2FE00
     - 0x30000


When changes to the tfm partition size in overlay configuration, remember to change the static partition size in pm_static.yml file.

For the TFM storage requirements, please refer to section :ref:`tfm-storage`.

UART Speed
------------
To configure the speed of Uart0 (used by the AT host) , there is a DTS overlay that sets the speed. there would be a DTS overlay file **boards/nrf9151dk_nrf9151_ns.overlay** (nRF9151 as an example) that contains the following: 

.. code-block:: sh

   &uart0 { 
               status = "okay"; 
               current-speed = <115200>; 
   }; 

Note that the speed of the UART0 should be consistent with the baudrate of the serial terminal, the default baudrate is 115200. You can change the baudrate in the loader application (v2.1.6 or later) and the serial terminal.


Terminal Line Ending
----------------------
The terminal line ending can be set to **CRLF**, **CR**, or **LF** for the AT commands to work correctly. In nuSIM, **CRLF** is used as the line ending and you can select one of the following line ending for your project:

+---------------------------+---------------------+
|Kconfig Option             |                     |
+===========================+=====================+
| CONFIG_CR_LF_TERMINATION  | CRLF                |
+---------------------------+---------------------+
| CONFIG_LF_TERMINATION     | LF                  |
+---------------------------+---------------------+
| CONFIG_CR_TERMINATION     | CR                  |
+---------------------------+---------------------+

Note that your choice of line ending should be consistent with the terminal line ending option in the IALA appliaction.
