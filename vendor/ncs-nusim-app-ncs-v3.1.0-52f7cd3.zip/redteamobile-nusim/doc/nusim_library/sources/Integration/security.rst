.. _security_guide:

Security
##################

AP Protection
------------------

The nRF SoC supports access port protection (AP-Protect). The mechanism
blocks the debugger from reading and writing to all CPU registers and
memory-mapped addresses.

To enable APPROTECT run

.. code-block:: sh

   nrfutil device protection-set All

This command enables the AP-Protect and resets the device. Note that the
latest `nRF Util <https://www.nordicsemi.com/Products/Development-tools/nRF-Util>`_ is needed:

.. code-block:: sh

   $ nrfutil install device
   [00:00:04] ###### 100% [Install packages] Install packages

   $ nrfutil --version
   nrfutil 8.0.0 (54d8087 2025-01-07)
   commit-hash: 54d8087a38b73b6e56942fb1b024b62365f06731
   commit-date: 2025-01-07
   host: x86_64-unknown-linux-gnu
   build-timestamp: 2025-01-07T14:26:42.070728557Z
   classification: nrf-external

   $ nrfutil device --version
   nrfutil-device 2.11.2 (481d897 2025-05-26)
   commit-hash: 481d897514d9cdb5b565c726e709cca667a0985c
   commit-date: 2025-05-26
   host: x86_64-unknown-linux-gnu
   build-timestamp: 2025-05-26T11:18:41.811426586Z
   classification: nrf-external

   Detected SEGGER J-Link version: JLink_V8.18

When building application for the nRF91 devices, use ``SB_CONFIG_APPROTECT_USE_UICR=y`` in the ``sysbuild.conf`` file to ensure that all images are built with the correct settings for AP protection.

In the development stage, you can debug the firmware without additional steps needed. **For production, the nrfutil command MUST be run to enable the access port protection. This is a security requirement.**
