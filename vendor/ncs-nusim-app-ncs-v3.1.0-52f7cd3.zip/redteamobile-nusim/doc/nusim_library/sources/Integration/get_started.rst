.. _startup_guide:

Get Started
########################

Introduction
==============

Purpose
-----------

This document is provided to describe nuSIM integration on Nordic nRF91xx series (xx =60/61/51) which is based on nRF9120 SoC, using nRF Connect SDK (NCS) containing TFM v2.1.2 and MCUBoot v2.1.0.


The command line example in this document applies to nRF9151 with NCS v3.1.0 and test with nRF9151DK.

Prerequisites
-----------------

* 
  NCS v3.1.0 .

* 
  Modem firmware version for nRF9160: v1.3.x, (x >= 4).

* 
  Modem firmware version for nRF9151/nRF9161: v2.0.x.

Get Delivery
==============

The github project is `redteamobile/ncs-nusim-app <https://github.com/redteamobile/ncs-nusim-app>`_.

To get the repository:

.. code-block:: sh

   west init -m https://github.com/redteamobile/ncs-nusim-app --mr ncs-v3.1.0 your-workspace

   cd your-workspace

   west update

Current branches for NCS, please choose one of the following:

+------------------------+--------------------------------------------------------+
|Branch Name             | Description                                            |
+========================+========================================================+
| main                   | The branch for latest NCS integration.                 |
+------------------------+--------------------------------------------------------+
|ncs-v2.5.2              | nuSIM for NCS v2.5.2 with Security certified           |
+------------------------+--------------------------------------------------------+
|ncs-v2.7.0              | nuSIM for NCS v2.7.0.                                  |
+------------------------+--------------------------------------------------------+
|ncs-v2.8.0              | nuSIM for NCS v2.8.0.                                  |
+------------------------+--------------------------------------------------------+
|ncs-v3.1.0              | nuSIM for NCS v3.1.0.                                  |
+------------------------+--------------------------------------------------------+

Notes: it is recommended to use the main branch, it includes the latest bug fixes and features, also the branch with security certified is recommended if you tend to choose more stable release.

.. _build-and-flash:

Build and Flash
================

.. important::
   The overlay config file is needed to enable the nuSIM features, it is located in the top level of the project, Two ways to add the overlay config file in your build command:

   - If you are using the VS Code nRF Connect extension, add the overlay config file in the 'Extra Kconfig fragments' section.
   - If you are using the west command line, add it in the build command with the -DEXTRA_CONF_FILE='../../overlay-nusim.conf' option.

There are two ways to build and flash the project:

West
---------

The procedure is the same for all nRF91xx modules. **Sysbuild** is used
for NCS 3.1.0, Let's take nRF9151 as an example:

.. code-block:: sh

   cd modules/lib/redteamobile-nusim/samples/basic

.. code-block:: sh

   west build -b nrf9151dk/nrf9151/ns --sysbuild -p -- -DEXTRA_CONF_FILE='../../overlay-nusim.conf'

Use following command to flash firmware:

.. code-block:: sh

   west flash

VS Code nRF Connect extension
-----------------------------------

If you are using the VS Code nRF Connect extension, you can build and flash the project by following these steps:

- Open the west project in VS Code.

- Configure the SDK and toolchain path.
   This can be ignored if you have already pre-existing nRF workspace.

   .. image:: ./pics/set_sdk_path.png
      :width: 30%
      :align: Left
      :alt: 

- Add the extra kconfig fragments
   .. image:: ./pics/add_overlay_conf.png
      :width: 30%
      :align: Left
      :alt: 

- Click "Build Configuration".

- Select the board and flash the firmware.
   .. image:: ./pics/nrf_extension_flash.png
      :width: 25%
      :align: Left
      :alt: 
   
   Be careful with the flash method, **'Erase and flash'** is not recommended, it will erase the entire chip and the nuSIM profile will be lost, please refer to section :ref:`data-protection-safe-flashing` for more details.

