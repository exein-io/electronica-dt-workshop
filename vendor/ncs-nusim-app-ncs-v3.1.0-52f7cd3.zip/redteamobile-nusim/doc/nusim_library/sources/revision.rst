.. _revision_history:

Revision History
#####################################

.. list-table:: Revision History
  :widths: 15 15 70
  :header-rows: 1

  * - Date
    - Version
    - Description
  * - 2023/06/26
    - V1.0.0
    - Initial version
  * - 2023/08/04
    - V1.1.0
    - | 1. Updated release files and api description for rtcosapi
      | 2. Added customized AT cmds
      | 3. Updated based on NRF SDK 2.4
  * - 2023/08/16
    - V1.2.0
    - Fix rot service loading failure issue
  * - 2023/11/08
    - V1.3.0
    - Update version for online/offline mode and add overlay description
  * - 2024/01/08
    - V1.4.0
    - Update per NCS 2.5
  * - 2024/01/19
    - V1.5.0
    - Enabled Assert for security evaluation.
  * - 2024/03/02
    - V1.6.0
    - Add MCUBoot.
  * - 2024/03/08
    - V1.7.0
    - Add mcuboot patch and remove mcuboot prebuilt files.
  * - 2024/04/12
    - V1.8.0
    - Update libs.
  * - 2024/05/14
    - V1.9.0
    - Update libs.
  * - 2024/06/12
    - V2.0.0
    - Update libs.
  * - 2024/06/18
    - V2.1.0
    - Update libs and add delivery comment/ap protection and more debug sections.
  * - 2024/08/27
    - V2.2.0
    - File Name changed to nRF91xx and update version
  * - 2024/11/15
    - V2.3.0
    - Add nusim as zephyr module.
  * - 2024/11/18
    - V2.4.0
    - Add sysbuild for NCS 2.7.
  * - 2024/12/24
    - V2.5.0
    - Add offline mode.
  * - 2025/1/14
    - V2.6.0
    - Add rom/ram info and initialize failure handling, modem trace for debug, static partition definitions.
  * - 2025/2/14
    - V2.7.0
    - Update for NCS 2.8.
  * - 2025/3/13
    - V2.7.1
    - Transform to rST .
  * - 2025/5/8
    - V2.7.2
    - Rename LA to IALA and fix blank page issue.
  * - 2025/5/13
    - V2.7.3
    - Update for linux IALA and west build command .
  * - 2025/5/21
    - V2.7.4
    - Update for IALA download profile.
  * - 2025/6/6
    - V2.7.5
    - Update for IALA.
  * - 2025/8/12
    - V2.7.6
    - Update for IALA error codes reference and HTTP Proxy and logo update.
  * - 2025/10/15
    - V2.7.7
    - Add data protection and safe flashing guidelines.
  * - 2025/11/21
    - V2.7.8
    - Update for ncs v3.1.0.